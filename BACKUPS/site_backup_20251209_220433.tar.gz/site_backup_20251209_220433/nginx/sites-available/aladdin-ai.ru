# ============================================
# NGINX КОНФИГУРАЦИЯ: Dashboard Support
# ============================================
# Сервер: 149.154.65.180
# Сайт: aladdin-ai.ru
# Дата: 3 декабря 2025
# Добавлено: Поддержка /dashboard и /admin
# ============================================

server {
    listen 80;
    server_name aladdin-ai.ru www.aladdin-ai.ru;
    
    # Редирект на HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    http2 on;
    server_name aladdin-ai.ru www.aladdin-ai.ru;
    
    # SSL сертификат (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/aladdin-ai.ru/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aladdin-ai.ru/privkey.pem;
    
    # SSL настройки
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Корневая директория сайта
    root /var/www/aladdin-ai.ru;
    
    # Индексные файлы
    index index.html index.htm;
    
    # ============================================
    # API ENDPOINTS (высокий приоритет)
    # ============================================
    
    # Dashboard API endpoints
    location /api/dashboard/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # CORS заголовки
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Content-Type, X-API-Key, X-Signature, X-Admin-Key' always;
        
        # Кэширование для публичных endpoints (опционально)
        proxy_cache_valid 200 60s;
        
        # Таймауты
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # API для реферальной программы
    location /api/referral/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # CORS заголовки
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Authorization, Content-Type' always;
        
        # Таймауты
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Все остальные API endpoints
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # CORS заголовки
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Content-Type, X-API-Key, X-Signature, X-Admin-Key' always;
        
        # Таймауты
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # ============================================
    # ПУБЛИЧНЫЙ DASHBOARD: /dashboard
    # ============================================
    
    location /dashboard {
        # Пробуем найти файл или директорию
        try_files $uri $uri/ /dashboard/index.html;
        
        # Если это директория, добавляем index.html
        if (-d $request_filename) {
            rewrite ^(.*)$ $1/index.html break;
        }
    }
    
    location /dashboard/ {
        # Отдаем статические файлы из директории dashboard
        alias /var/www/html/dashboard/;
        
        # Индексный файл
        index index.html;
        
        # Пробуем найти файл, если нет - отдаем index.html
        try_files $uri $uri/ /dashboard/index.html;
        
        # Заголовки для статических файлов
        expires 1h;
        add_header Cache-Control "public, must-revalidate";
        
        # MIME типы
        types {
            text/html html;
            text/css css;
            application/javascript js;
            image/png png;
            image/jpeg jpg jpeg;
            image/svg+xml svg;
        }
    }
    
    # ============================================
    # АДМИНСКИЙ DASHBOARD: /admin (будущее)
    # ============================================
    
    location /admin {
        # Пробуем найти файл или директорию
        try_files $uri $uri/ /admin/index.html;
        
        # Если это директория, добавляем index.html
        if (-d $request_filename) {
            rewrite ^(.*)$ $1/index.html break;
        }
    }
    
    location /admin/ {
        # Отдаем статические файлы из директории admin
        alias /var/www/html/admin/;
        
        # Индексный файл
        index index.html;
        
        # Пробуем найти файл, если нет - отдаем index.html
        try_files $uri $uri/ /admin/index.html;
        
        # Заголовки для статических файлов
        expires 1h;
        add_header Cache-Control "public, must-revalidate";
        
        # MIME типы
        types {
            text/html html;
            text/css css;
            application/javascript js;
            image/png png;
            image/jpeg jpg jpeg;
            image/svg+xml svg;
        }
    }
    
    # ============================================
    # РЕФЕРАЛЬНЫЕ ССЫЛКИ: /invite/{code}
    # ============================================
    
    # Обработка реферальных ссылок
    location ~ ^/invite/([A-Z0-9-]+)$ {
        # Проксируем на Python backend
        proxy_pass http://localhost:8000/invite/$1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Таймауты
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # ============================================
    # СТАТИЧЕСКИЕ ФАЙЛЫ
    # ============================================
    
    # Статические файлы (CSS, JS, изображения)
    location /static/ {
        alias /var/www/aladdin-ai.ru/static/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # Статические файлы из корня (styles.css, etc.)
    location ~ \.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        root /var/www/aladdin-ai.ru;
        expires 1h;
        add_header Cache-Control "public, must-revalidate";
        access_log off;
    }
    
    # ============================================
    # ОСНОВНОЙ САЙТ
    # ============================================
    
    # Главная страница и остальные страницы
    location / {
        # Пробуем найти файл
        try_files $uri $uri/ /index.html;
        
        # Если файл не найден, отдаем index.html (для SPA)
        if (!-e $request_filename) {
            rewrite ^(.*)$ /index.html break;
        }
    }
    
    # ============================================
    # ЛОГИРОВАНИЕ
    # ============================================
    
    access_log /var/log/nginx/aladdin-ai.ru-access.log;
    error_log /var/log/nginx/aladdin-ai.ru-error.log;
}

# ============================================
# ИНСТРУКЦИИ ПО УСТАНОВКЕ
# ============================================
# 1. Создайте бэкап текущей конфигурации:
#    sudo cp /etc/nginx/sites-available/aladdin-ai.ru /etc/nginx/sites-available/aladdin-ai.ru.backup
#
# 2. Скопируйте этот файл в /etc/nginx/sites-available/aladdin-ai.ru
#    sudo cp NGINX_CONFIG_DASHBOARD.conf /etc/nginx/sites-available/aladdin-ai.ru
#
# 3. Проверьте конфигурацию:
#    sudo nginx -t
#
# 4. Если проверка прошла успешно, перезагрузите nginx:
#    sudo systemctl reload nginx
#
# 5. Проверьте работу:
#    - https://aladdin-ai.ru/dashboard
#    - https://aladdin-ai.ru/api/dashboard/public/stats
#
# ВАЖНО:
# - Убедитесь, что SSL сертификат установлен (Let's Encrypt)
# - Убедитесь, что Python backend работает на localhost:8000
# - Убедитесь, что директория /var/www/html/dashboard/ существует
# - Проверьте права доступа к файлам (chown -R www-data:www-data /var/www/html)

