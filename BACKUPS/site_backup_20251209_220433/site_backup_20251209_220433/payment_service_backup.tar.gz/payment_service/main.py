"""
Aladdin Payment Service - FastAPI Backend
Основной файл приложения для обработки платежей
"""

from datetime import datetime, timezone
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.config import settings, verify_webhook_signature
from app.database import get_session, engine
from app.models import Base, Payment, ActivationCode
from app.schemas import PaymentCreateRequest
from app.payment_methods import list_payment_methods, get_payment_method
from app.providers.mock_psp import provider
from app.utils import hash_pin, verify_pin, generate_activation_code, code_expiration, now_utc
from app.rate_limit import get_rate_limiter
from app.config import settings
from fastapi import HTTPException as FastAPIHTTPException

app = FastAPI(title="Aladdin Payment Service", version="1.0.0")


# Инициализация базы данных
@app.on_event("startup")
async def init_db():
    """Создание таблиц при запуске"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# Middleware для CORS (если нужно)
@app.middleware("http")
async def cors_middleware(request: Request, call_next):
    """Добавляет CORS заголовки"""
    response = await call_next(request)
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key, X-Signature, X-Admin-Key"
    return response


# Проверка API ключа
async def verify_api_key(x_api_key: Optional[str] = Header(None)):
    """Проверка API ключа из заголовка"""
    if not x_api_key or x_api_key != settings.api_key_public:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key


# Эндпоинты

@app.get("/")
async def root():
    """Корневой эндпоинт"""
    return {"service": "Aladdin Payment Service", "version": "1.0.0", "status": "running"}


@app.get("/api/payment-methods")
async def get_payment_methods():
    """Возвращает список всех доступных методов оплаты"""
    return {"methods": list_payment_methods()}


@app.get("/api/manual-transfer/info")
async def get_manual_transfer_info():
    """Возвращает информацию для ручного перевода (номер карты)"""
    return {
        "card_number": settings.card_number,
        "card_holder_name": settings.card_holder_name
    }


@app.post("/api/payments/create")
async def create_payment(
    request: PaymentCreateRequest,
    session: AsyncSession = Depends(get_session),
    api_key: str = Depends(verify_api_key)
):
    """
    Создает новый платеж
    
    Требует:
    - X-API-Key заголовок
    - Согласие на обработку ПДн (personal_data_consent: true)
    """
    # Проверка согласия на обработку ПДн
    if not request.personal_data_consent:
        raise HTTPException(
            status_code=400,
            detail="Согласие на обработку персональных данных обязательно (152-ФЗ)"
        )
    
    # Проверка метода оплаты
    method = get_payment_method(request.payment_method)
    if not method:
        raise HTTPException(status_code=400, detail=f"Неизвестный метод оплаты: {request.payment_method}")
    
    # Создание платежа в БД
    payment = Payment(
        alias=request.user_alias,
        pin_hash=hash_pin(request.pin),
        tariff_id=request.tariff_id,
        amount=int(request.amount * 100),  # Конвертируем в копейки
        payment_method=request.payment_method,
        status="created",
        # ✅ Сохранение согласия на обработку ПДн
        personal_data_consent=True,
        consent_timestamp=datetime.fromisoformat(request.consent_timestamp.replace('Z', '+00:00')) if request.consent_timestamp else now_utc(),
        consent_ip=request.consent_ip
    )
    
    session.add(payment)
    await session.commit()
    await session.refresh(payment)
    
    # Создание платежа в PSP (провайдере)
    if request.payment_method == "manual_transfer":
        # Для ручного перевода не нужен PSP
        response_data = {
            "payment_id": payment.id,
            "status": "pending",
            "method": "manual_transfer",
            "card_number": settings.card_number,
            "card_holder_name": settings.card_holder_name,
            "amount": request.amount,
            "expires_at": (now_utc().replace(tzinfo=None) + code_expiration(7).replace(tzinfo=None) - now_utc().replace(tzinfo=None)).isoformat()
        }
    else:
        # Для других методов создаем платеж в PSP
        psp_result = await provider.create_payment(
            amount=int(request.amount * 100),
            currency="RUB"
        )
        
        payment.psp_payment_id = psp_result["payment_id"]
        await session.commit()
        
        response_data = {
            "payment_id": payment.id,
            "redirect_url": psp_result["redirect_url"],
            "qr_data": psp_result.get("qr_data"),
            "expires_at": psp_result["expires_at"].isoformat(),
            "status": "created"
        }
    
    return response_data


@app.post("/api/payments/confirm")
async def confirm_payment(
    request: Request,
    session: AsyncSession = Depends(get_session),
    x_signature: Optional[str] = Header(None, alias="X-Signature")
):
    """
    Webhook от банка для подтверждения платежа
    
    Требует:
    - X-Signature заголовок для проверки подписи
    """
    body = await request.body()
    
    # Проверка подписи
    if not verify_webhook_signature(body, x_signature or "", settings.webhook_secret):
        raise HTTPException(status_code=401, detail="Invalid signature")
    
    # Парсинг данных webhook (заглушка - нужно адаптировать под реальный формат)
    import json
    data = await request.json()
    
    payment_id = data.get("payment_id")
    psp_txn_id = data.get("pspTxnId")
    status = data.get("status")
    
    if status != "paid":
        return {"status": "ignored", "reason": f"Status is {status}, not 'paid'"}
    
    # Поиск платежа
    result = await session.execute(
        select(Payment).where(Payment.psp_payment_id == psp_txn_id)
    )
    payment = result.scalar_one_or_none()
    
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    if payment.status == "paid":
        # Idempotency: уже обработан
        return {"status": "already_processed", "payment_id": payment.id}
    
    # Обновление статуса
    payment.status = "paid"
    await session.commit()
    
    # Генерация кода активации
    code = generate_activation_code()
    activation = ActivationCode(
        code=code,
        payment_id=payment.id,
        expires_at=code_expiration(30)
    )
    session.add(activation)
    await session.commit()
    
    return {
        "status": "confirmed",
        "payment_id": payment.id,
        "activation_code": code
    }


@app.post("/api/activation/retrieve")
async def retrieve_activation_code(
    alias: str,
    pin: str,
    request: Request,
    session: AsyncSession = Depends(get_session)
):
    """
    Получение кода активации по alias и PIN
    
    Защищено rate limiting (5 запросов/минуту)
    """
    # Rate limiting
    client_ip = request.client.host
    rate_limiter = get_rate_limiter(
        settings.rate_limit_retrieve_max,
        settings.rate_limit_retrieve_window
    )
    is_allowed, remaining = rate_limiter.is_allowed(f"{alias}:{client_ip}")
    if not is_allowed:
        raise FastAPIHTTPException(
            status_code=429,
            detail="Rate limit exceeded. Try again later.",
            headers={"X-RateLimit-Remaining": "0"}
        )
    
    # Поиск платежа
    result = await session.execute(
        select(Payment).where(Payment.alias == alias)
    )
    payment = result.scalar_one_or_none()
    
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    # Проверка PIN
    if not verify_pin(pin, payment.pin_hash):
        raise HTTPException(status_code=401, detail="Invalid PIN")
    
    if payment.status != "paid":
        raise HTTPException(status_code=400, detail=f"Payment status is {payment.status}, not 'paid'")
    
    # Поиск кода активации
    result = await session.execute(
        select(ActivationCode).where(ActivationCode.payment_id == payment.id)
    )
    activation = result.scalar_one_or_none()
    
    if not activation:
        raise HTTPException(status_code=404, detail="Activation code not found")
    
    if activation.redeemed:
        raise HTTPException(status_code=400, detail="Activation code already redeemed")
    
    if activation.expires_at < now_utc():
        raise HTTPException(status_code=400, detail="Activation code expired")
    
    return {
        "code": activation.code,
        "expires_at": activation.expires_at.isoformat(),
        "tariff_id": payment.tariff_id
    }


@app.post("/api/activation/verify")
async def verify_activation_code(
    code: str,
    session: AsyncSession = Depends(get_session)
):
    """Проверка кода активации без погашения"""
    result = await session.execute(
        select(ActivationCode).where(ActivationCode.code == code)
    )
    activation = result.scalar_one_or_none()
    
    if not activation:
        raise HTTPException(status_code=404, detail="Activation code not found")
    
    if activation.redeemed:
        return {"valid": False, "reason": "already_redeemed"}
    
    if activation.expires_at < now_utc():
        return {"valid": False, "reason": "expired"}
    
    return {"valid": True, "expires_at": activation.expires_at.isoformat()}


@app.post("/api/activation/activate")
async def activate_code(
    code: str,
    session: AsyncSession = Depends(get_session)
):
    """Погашение кода активации"""
    result = await session.execute(
        select(ActivationCode).where(ActivationCode.code == code)
    )
    activation = result.scalar_one_or_none()
    
    if not activation:
        raise HTTPException(status_code=404, detail="Activation code not found")
    
    if activation.redeemed:
        raise HTTPException(status_code=400, detail="Activation code already redeemed")
    
    if activation.expires_at < now_utc():
        raise HTTPException(status_code=400, detail="Activation code expired")
    
    activation.redeemed = True
    activation.redeemed_at = now_utc()
    await session.commit()
    
    return {"status": "activated", "code": code}


# ✅ Endpoints для мобильного приложения (с familyId и deviceId)
@app.post("/api/subscription/activation/verify")
async def verify_activation_code_mobile(
    request: Request,
    session: AsyncSession = Depends(get_session),
    api_key: str = Depends(verify_api_key)
):
    """Проверка кода активации для мобильного приложения"""
    data = await request.json()
    code = data.get("code", "").strip().upper()
    family_id = data.get("familyId", "default")
    device_id = data.get("deviceId", "unknown")
    
    if not code:
        raise HTTPException(status_code=400, detail="Code is required")
    
    result = await session.execute(
        select(ActivationCode).where(ActivationCode.code == code)
    )
    activation = result.scalar_one_or_none()
    
    if not activation:
        raise HTTPException(status_code=404, detail="Activation code not found")
    
    # Получаем информацию о платеже
    payment_result = await session.execute(
        select(Payment).where(Payment.id == activation.payment_id)
    )
    payment = payment_result.scalar_one_or_none()
    
    if activation.redeemed:
        return {
            "status": "redeemed",
            "tariffId": payment.tariff_id if payment else "unknown",
            "expiresAt": activation.expires_at.isoformat()
        }
    
    if activation.expires_at < now_utc():
        return {
            "status": "expired",
            "tariffId": payment.tariff_id if payment else "unknown",
            "expiresAt": activation.expires_at.isoformat()
        }
    
    return {
        "status": "active",
        "tariffId": payment.tariff_id if payment else "unknown",
        "expiresAt": activation.expires_at.isoformat()
    }


@app.post("/api/subscription/activation/activate")
async def activate_code_mobile(
    request: Request,
    session: AsyncSession = Depends(get_session),
    api_key: str = Depends(verify_api_key)
):
    """Активация кода для мобильного приложения"""
    data = await request.json()
    code = data.get("code", "").strip().upper()
    family_id = data.get("familyId", "default")
    device_id = data.get("deviceId", "unknown")
    
    if not code:
        raise HTTPException(status_code=400, detail="Code is required")
    
    result = await session.execute(
        select(ActivationCode).where(ActivationCode.code == code)
    )
    activation = result.scalar_one_or_none()
    
    if not activation:
        raise HTTPException(status_code=404, detail="Activation code not found")
    
    # Получаем информацию о платеже
    payment_result = await session.execute(
        select(Payment).where(Payment.id == activation.payment_id)
    )
    payment = payment_result.scalar_one_or_none()
    
    if activation.redeemed:
        raise HTTPException(status_code=400, detail="Activation code already redeemed")
    
    if activation.expires_at < now_utc():
        raise HTTPException(status_code=400, detail="Activation code expired")
    
    # Помечаем код как использованный
    activation.redeemed = True
    activation.redeemed_at = now_utc()
    await session.commit()
    
    # Вычисляем дату истечения подписки (30 дней от момента активации)
    expires_at = now_utc() + code_expiration(30) - code_expiration(0)
    
    return {
        "success": True,
        "code": code,
        "tariffId": payment.tariff_id if payment else "unknown",
        "expiresAt": expires_at.isoformat()
    }


@app.post("/api/admin/payments/confirm-manual")
async def confirm_manual_payment(
    payment_id: str,
    psp_txn_id: Optional[str] = None,
    session: AsyncSession = Depends(get_session),
    x_admin_key: Optional[str] = Header(None, alias="X-Admin-Key")
):
    """
    Ручное подтверждение прямого банковского перевода
    
    Требует:
    - X-Admin-Key заголовок
    """
    if not x_admin_key or x_admin_key != settings.admin_key:
        raise HTTPException(status_code=401, detail="Invalid admin key")
    
    # Поиск платежа
    result = await session.execute(
        select(Payment).where(Payment.id == payment_id)
    )
    payment = result.scalar_one_or_none()
    
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    if payment.status == "paid":
        # Idempotency
        result = await session.execute(
            select(ActivationCode).where(ActivationCode.payment_id == payment.id)
        )
        activation = result.scalar_one_or_none()
        return {
            "status": "already_processed",
            "payment_id": payment.id,
            "activation_code": activation.code if activation else None
        }
    
    # Обновление статуса
    payment.status = "paid"
    if psp_txn_id:
        payment.psp_payment_id = psp_txn_id
    await session.commit()
    
    # Генерация кода активации
    code = generate_activation_code()
    activation = ActivationCode(
        code=code,
        payment_id=payment.id,
        expires_at=code_expiration(30)
    )
    session.add(activation)
    await session.commit()
    
    return {
        "status": "confirmed",
        "payment_id": payment.id,
        "activation_code": code
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
