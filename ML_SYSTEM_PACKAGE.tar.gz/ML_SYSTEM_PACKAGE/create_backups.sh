#!/bin/bash

# Скрипт для создания бэкапов критических файлов перед изменениями
# ALADDIN iOS App - Этап 0: Исправление Mock данных

echo "🛡️ Создание бэкапов критических файлов..."
echo "📅 $(date)"

# Создать папку для бэкапов
BACKUP_DIR="backups_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "📁 Создаю бэкапы в папке: $BACKUP_DIR"

# 🔴 КРИТИЧЕСКИ ВАЖНЫЕ ФАЙЛЫ
echo "🔴 Копирование критических файлов..."

cp "Core/Config/AppConfig.swift" "$BACKUP_DIR/AppConfig.swift.backup"
cp "Core/Network/APIService.swift" "$BACKUP_DIR/APIService.swift.backup"
cp "ALADDIN/Info.plist" "$BACKUP_DIR/Info.plist.backup"
cp "ALADDIN.xcodeproj/project.pbxproj" "$BACKUP_DIR/project.pbxproj.backup"

# 🟡 ВАЖНЫЕ ФАЙЛЫ
echo "🟡 Копирование важных файлов..."

cp "ViewModels/NotificationsViewModel.swift" "$BACKUP_DIR/NotificationsViewModel.swift.backup"
cp "ViewModels/AIAssistantViewModel.swift" "$BACKUP_DIR/AIAssistantViewModel.swift.backup"
cp "Core/Analytics/AnalyticsService.swift" "$BACKUP_DIR/AnalyticsService.swift.backup"
cp "Core/Managers/KeychainManager.swift" "$BACKUP_DIR/KeychainManager.swift.backup"

# ГЛАВНЫЙ ФАЙЛ ЛОКАЛИЗАЦИИ
cp "Core/Localization/LocalizationManager.swift" "$BACKUP_DIR/LocalizationManager.swift.backup"

# 🌐 ЛОКАЛИЗАЦИЯ
echo "🌐 Копирование локализационных файлов..."

cp -r "LocalizedVersions" "$BACKUP_DIR/LocalizedVersions.backup"

# 🖥️ ЭКРАНЫ С MOCK ДАННЫМИ
echo "🖥️ Копирование экранов с mock данными..."

cp "Screens/22_DeviceDetailScreen.swift" "$BACKUP_DIR/DeviceDetailScreen.swift.backup"
cp "Screens/27_ProtectionStatsScreen.swift" "$BACKUP_DIR/ProtectionStatsScreen.swift.backup"

# 📊 СТАТИСТИКА
echo "📊 Проверка бэкапов..."
ls -la "$BACKUP_DIR/" | wc -l | xargs echo "Создано файлов бэкапа:"

echo "✅ Бэкапы созданы успешно!"
echo "📂 Расположение: $BACKUP_DIR"
echo ""
echo "⚠️  ВАЖНО: Не удаляйте папку $BACKUP_DIR до завершения всех изменений!"
echo "🔄 Для восстановления: cp $BACKUP_DIR/*.backup соответствующие/файлы"