//
// 13_SupportScreen_Localized.swift
// ALADDIN iOS App
//
// ✅ ЛОКАЛИЗОВАННАЯ ВЕРСИЯ - ГОТОВА ДЛЯ АНГЛИЙСКОГО ЯЗЫКА
// Дата локализации: 2025-11-05
// Статус: ✅ Основные элементы локализованы (9 ключей)
// Примечание: FAQ вопросы/ответы требуют дополнительной локализации (35+ вопросов)
// Все основные тексты используют LocalizationManager.localized()
// Поддерживает: RU, EN (и другие языки через словарь)
//
import SwiftUI

/// 💬 Support Screen
/// Экран поддержки - помощь и FAQ
/// Источник дизайна: комбинация из разных wireframes
struct SupportScreen: View {
    
    // MARK: - State
    
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var navigationManager: NavigationManager
    @EnvironmentObject private var localizationManager: LocalizationManager
    @State private var searchText: String = ""
    
    struct FAQItem: Identifiable {
        let id = UUID()
        let icon: String
        let question: String
        let answer: String
        var isExpanded: Bool = false
    }
    
    @State private var faqItems: [FAQItem] = [
        // ==========================================
        // 📋 ОБЩИЕ ВОПРОСЫ
        // ==========================================
        
        FAQItem(icon: "🛡️", question: "От чего защищает система?", answer: "ALADDIN защищает от 100+ видов опасностей в интернете. Это как сторож для твоего телефона - он не пускает плохих и оберегает тебя от вирусов, мошенников и опасных сайтов.\n\nНаша система работает 24/7 и проверяет всё, что происходит на твоем устройстве."),
        
        FAQItem(icon: "👶", question: "Как система защищает детей?", answer: "Мы защищаем детей как настоящие супергерои! 🦸\n\n• Не пускаем на опасные сайты (как забор вокруг детской площадки)\n• Не даём играть слишком долго (помогаем отдыхать)\n• Следим, чтобы незнакомцы не писали твоему ребёнку\n• Учим безопасности через игры (весело и полезно!)\n• Родители видят, что происходит (но не читают личные сообщения)"),
        
        FAQItem(icon: "👴", question: "Как система защищает пожилых?", answer: "Для бабушек и дедушек мы сделали специальную защиту:\n\n• Блокируем звонки от мошенников (они часто звонят пожилым)\n• Проверяем все сайты перед открытием\n• Делаем простой интерфейс - всё понятно даже если не дружишь с телефоном\n• Можно управлять голосом (сказал \"позвони внуку\" - и звонок сразу)\n• Красная кнопка SOS - быстро позвать помощь"),
        
        FAQItem(icon: "🔐", question: "Безопасны ли мои данные?", answer: "Да, твои данные в полной безопасности! 🔒\n\nМы используем:\n• Военное шифрование (как в банках и армии)\n• Все данные хранятся в России\n• Соблюдаем все законы о защите\n• В Premium - полная анонимность (никто не узнает даже нас)"),
        
        // ==========================================
        // 🛡️ КИБЕРУГРОЗЫ (6 вопросов)
        // ==========================================
        
        FAQItem(icon: "🦠", question: "Что такое вирусы и трояны?", answer: "Вирус в телефоне - это как простуда для компьютера. Он может:\n• Удалить твои фотографии\n• Украсть пароли\n• Сломать телефон\n\nТроян - это вирус, который прячется в красивой программе (как троянский конь из сказки). Ты думаешь, что скачал игру, а на самом деле - вирус!\n\n✅ ALADDIN находит и удаляет вирусы до того, как они причинят вред."),
        
        FAQItem(icon: "🔒", question: "Что такое Ransomware (шифровальщики)?", answer: "Это очень злой вирус-бандит! Он запирает все твои файлы и требует денег, чтобы вернуть их.\n\nКак это происходит:\n1. Ты скачиваешь вредоносную программу\n2. Она шифрует (запирает) все файлы\n3. На экране появляется: \"Заплати 50,000₽ или потеряешь всё!\"\n\n✅ ALADDIN не даёт таким программам попасть на твой телефон."),
        
        FAQItem(icon: "🕵️", question: "Что такое шпионское ПО?", answer: "Шпион - это программа-невидимка, которая следит за тобой:\n• Видит твои пароли\n• Читает сообщения\n• Видит, куда ты ходишь\n• Слушает разговоры\n\nЭто как если бы кто-то всё время шёл за тобой и записывал всё, что ты делаешь!\n\n✅ ALADDIN находит и удаляет шпионов."),
        
        FAQItem(icon: "🌐", question: "Что такое фишинговые сайты?", answer: "Фишинг - это когда мошенники делают поддельный сайт, похожий на настоящий банк или магазин.\n\nКак это работает:\n1. Ты думаешь, что зашёл на сайт своего банка\n2. Вводишь пароль\n3. Мошенники получают твой пароль и крадут деньги!\n\nЭто как поддельный магазин - выглядит как настоящий, но обманывает!\n\n✅ ALADDIN проверяет все сайты и предупреждает: \"Осторожно! Это подделка!\""),
        
        FAQItem(icon: "📱", question: "Что такое поддельные приложения?", answer: "Поддельное приложение - это как поддельный телефон. Выглядит как настоящий, но это обман!\n\nМошенники делают:\n• Поддельный Сбербанк (чтобы украсть твои деньги)\n• Поддельный WhatsApp (чтобы читать сообщения)\n• Поддельные игры (чтобы украсть пароли)\n\n✅ ALADDIN проверяет каждое приложение перед установкой и предупреждает об опасности."),
        
        FAQItem(icon: "🔗", question: "Что такое вредоносные ссылки?", answer: "Вредоносная ссылка - это как дверь в плохое место. Ты нажимаешь на неё, и попадаешь в ловушку!\n\nОткуда они берутся:\n• В сообщениях от незнакомцев\n• В рекламе на сайтах\n• В письмах (\"Поздравляем! Вы выиграли...\")\n\n✅ ALADDIN проверяет все ссылки и говорит: \"Стоп! Эта ссылка опасна!\""),
        
        // ==========================================
        // 💰 МОШЕННИЧЕСТВО (5 вопросов)
        // ==========================================
        
        FAQItem(icon: "📞", question: "Что такое телефонное мошенничество?", answer: "Телефонные мошенники звонят и обманывают людей:\n• \"Здравствуйте, это банк! Ваш счёт заблокирован, назовите пароль\"\n• \"Это полиция! Ваш сын попал в беду, нужны деньги\"\n• \"Поздравляем! Вы выиграли миллион! Переведите 5000₽ для получения\"\n\nПомни: НИКОГДА не называй пароли по телефону!\n\n✅ ALADDIN блокирует звонки от известных мошенников."),
        
        FAQItem(icon: "💳", question: "Что такое финансовое мошенничество?", answer: "Финансовые мошенники хотят украсть твои деньги:\n• \"Ваша карта заблокирована, перейдите по ссылке\"\n• \"Вы выиграли приз, заплатите налог 3000₽\"\n• \"Срочно! Нужно перевести деньги за лечение родственника\"\n\nПравило: Банки и государство НИКОГДА не просят деньги по телефону или в сообщениях!\n\n✅ ALADDIN предупреждает о таких сообщениях."),
        
        FAQItem(icon: "🎭", question: "Что такое социальная инженерия?", answer: "Социальная инженерия - это когда мошенник обманывает тебя словами, а не взломом.\n\nПримеры:\n• \"Я ваш новый коллега, нужен доступ к системе\"\n• \"Я из технической поддержки, назовите пароль для проверки\"\n• \"Ваша мама в больнице! Нужны срочно деньги!\"\n\nОни играют на твоих эмоциях - страхе, жадности, желании помочь.\n\n✅ ALADDIN учит распознавать такие обманы."),
        
        FAQItem(icon: "🏦", question: "Что такое поддельные банки?", answer: "Поддельный банк - это сайт, который выглядит как настоящий банк, но это подделка!\n\nКак отличить:\n• Настоящий банк: sberbank.ru\n• Поддельный: sberbank-проверка.ru (с дефисом и другим окончанием)\n\nМошенники копируют дизайн настоящего банка, но это обман!\n\n✅ ALADDIN проверяет адрес сайта и предупреждает: \"Это НЕ настоящий банк!\""),
        
        FAQItem(icon: "📧", question: "Что такое фишинговые письма?", answer: "Фишинговое письмо - это обманное письмо, которое просит тебя сделать что-то опасное:\n• \"Ваш аккаунт заблокирован, войдите по ссылке\"\n• \"Вы выиграли приз! Кликните здесь\"\n• \"Кто-то пытался войти в ваш аккаунт, проверьте здесь\"\n\n❌ НЕ нажимай на ссылки в таких письмах!\n\n✅ ALADDIN проверяет письма и предупреждает об опасности."),
        
        // ==========================================
        // 👶 ДЕТСКИЕ УГРОЗЫ (5 вопросов)
        // ==========================================
        
        FAQItem(icon: "🚫", question: "Что такое неподходящий контент для детей?", answer: "Неподходящий контент - это то, что дети не должны видеть:\n• Страшные видео (убийства, насилие)\n• Взрослые сайты\n• Картинки и видео для взрослых\n• Фильмы и игры с жестокостью\n\nЭто может напугать ребёнка или научить плохому!\n\n✅ ALADDIN автоматически блокирует всё неподходящее для возраста ребёнка."),
        
        FAQItem(icon: "😢", question: "Что такое кибербуллинг?", answer: "Кибербуллинг - это когда дети в интернете обижают других детей:\n• Обзывают в чатах\n• Публикуют обидные фотографии\n• Пишут угрозы\n• Создают группы, чтобы травить кого-то\n\nЭто очень больно и страшно!\n\n✅ ALADDIN видит оскорбления и предупреждает родителей. Мы также учим детей, как защитить себя."),
        
        FAQItem(icon: "👥", question: "Что такое опасные знакомства в интернете?", answer: "Опасные знакомства - это когда незнакомый взрослый человек пытается подружиться с ребёнком:\n• \"Привет! Как дела? Давай дружить\"\n• \"Ты такой умный! Давай встретимся?\"\n• \"Не рассказывай родителям о нашем разговоре\"\n\n⚠️ ОПАСНО! Взрослые не должны дружить с детьми в интернете!\n\n✅ ALADDIN видит подозрительные разговоры и сразу сообщает родителям."),
        
        FAQItem(icon: "🎮", question: "Что такое игровая зависимость?", answer: "Игровая зависимость - это когда ребёнок играет слишком много и не может остановиться:\n• Играет целый день вместо уроков\n• Не ест, не спит из-за игр\n• Злится, когда говорят перестать играть\n• Перестаёт общаться с друзьями\n\nЭто вредно для здоровья и учёбы!\n\n✅ ALADDIN помогает контролировать время игр и учит балансу."),
        
        FAQItem(icon: "💸", question: "Что такое случайные покупки?", answer: "Случайные покупки - это когда ребёнок случайно тратит деньги родителей:\n• Нажимает \"Купить\" в игре\n• Вводит пароль от карты родителя\n• Покупает дорогие вещи в приложениях\n\nРодители не хотят, чтобы ребёнок тратил деньги без разрешения!\n\n✅ ALADDIN требует подтверждения взрослого перед любой покупкой."),
        
        // ==========================================
        // 🔒 УТЕЧКИ ДАННЫХ (2 вопроса)
        // ==========================================
        
        FAQItem(icon: "🔑", question: "Что такое кража паролей?", answer: "Кража паролей - это когда мошенники узнают твой пароль и входят в твои аккаунты:\n• Крадут деньги из банка\n• Читают твои сообщения\n• Публикуют что-то от твоего имени\n• Покупают что-то на твои деньги\n\n❌ НЕ используй один пароль везде!\n\n✅ ALADDIN проверяет, не украли ли твои пароли."),
        
        FAQItem(icon: "👁️", question: "Что такое нарушение приватности?", answer: "Нарушение приватности - это когда кто-то видит то, что должен видеть только ты:\n• Твои фотографии\n• Личные сообщения\n• Где ты находишься\n• Что ты ищешь в интернете\n\nЭто как если бы кто-то подглядывал в твою дверь!\n\n✅ ALADDIN защищает твою приватность и не даёт следить за тобой."),
        
        // ==========================================
        // 🎭 ПОДДЕЛКИ (3 вопроса)
        // ==========================================
        
        FAQItem(icon: "🎬", question: "Что такое Deepfake видео?", answer: "Deepfake - это видео, где лицо одного человека заменяют на лицо другого с помощью компьютера.\n\nЭто очень опасно:\n• Мошенники могут сделать видео, где ты говоришь то, чего не говорил\n• Могут обмануть твоих друзей\n• Использовать для вымогательства\n\nЭто как маска, которую нельзя снять!\n\n✅ ALADDIN Premium обнаруживает поддельные видео и предупреждает."),
        
        FAQItem(icon: "🎤", question: "Что такое поддельные голоса?", answer: "Поддельный голос - это когда компьютер копирует голос человека:\n• Мошенник звонит маме и говорит голосом сына: \"Мама, срочно нужны деньги!\"\n• Звучит как настоящий голос, но это обман!\n\n⚠️ Если кто-то звонит и просит деньги - всегда перезвони этому человеку сам!\n\n✅ ALADDIN Premium анализирует голос и определяет подделку."),
        
        FAQItem(icon: "📰", question: "Что такое фейковые новости?", answer: "Фейковые новости - это ложная информация, которая распространяется как правда:\n• \"Учёные нашли лекарство от всех болезней!\" (ложь)\n• \"Землетрясение в Москве!\" (ложь, если его не было)\n• \"Все банки закрываются!\" (ложь)\n\nЭто делается, чтобы обмануть людей или посеять панику.\n\n✅ ALADDIN проверяет новости и показывает, правда это или нет."),
        
        // ==========================================
        // 🌐 ИНТЕРНЕТ-УГРОЗЫ (4 вопроса)
        // ==========================================
        
        FAQItem(icon: "⚠️", question: "Что такое опасные сайты?", answer: "Опасный сайт - это сайт, который может навредить твоему телефону:\n• Заразить вирусом\n• Украсть пароли\n• Обмануть тебя\n• Показать плохой контент\n\n✅ ALADDIN проверяет каждый сайт перед открытием и предупреждает: \"Этот сайт опасен! Не открывай!\""),
        
        FAQItem(icon: "📥", question: "Что такое подозрительные загрузки?", answer: "Подозрительная загрузка - это файл, который может быть опасным:\n• Программа может оказаться вирусом\n• Фото может содержать вирус\n• Игра может украсть данные\n\nКак понять:\n• Файл от незнакомого отправителя\n• Слишком хорошее предложение (\"Скачай и выиграй миллион!\")\n• Непонятное расширение файла\n\n✅ ALADDIN проверяет каждый файл перед скачиванием."),
        
        FAQItem(icon: "📡", question: "Что такое небезопасные Wi-Fi?", answer: "Небезопасный Wi-Fi - это публичная сеть, которая может быть ловушкой:\n• В кафе, аэропорту, метро\n• Мошенники могут перехватить твои данные\n• Украсть пароли\n• Видеть, что ты делаешь\n\nЭто как если бы кто-то стоял за твоей спиной и смотрел, что ты печатаешь!\n\n✅ ALADDIN предупреждает об опасных сетях и защищает твои данные через VPN."),
        
        FAQItem(icon: "🕵️", question: "Что такое Man-in-the-middle атаки?", answer: "Man-in-the-middle (человек посередине) - это когда мошенник перехватывает разговор между тобой и банком:\n\nКак это работает:\n1. Ты думаешь, что общаешься с банком\n2. На самом деле мошенник стоит \"посередине\"\n3. Он видит всё, что ты отправляешь (пароли, данные карты)\n4. Может изменить ответ банка на свой\n\nЭто как разговор через подслушивающего!\n\n✅ ALADDIN Premium использует специальное шифрование, чтобы никто не мог подслушать."),
        
        // ==========================================
        // 📱 МОБИЛЬНЫЕ УГРОЗЫ (3 вопроса)
        // ==========================================
        
        FAQItem(icon: "📱", question: "Что такое вредоносные приложения?", answer: "Вредоносное приложение - это программа, которая выглядит нормально, но делает плохие вещи:\n• Крадёт твои фотографии\n• Читает сообщения\n• Видит, где ты находишься\n• Тратит твои деньги\n• Заражает телефон вирусом\n\nОни часто прячутся в:\n• Бесплатных играх\n• \"Крутых\" программах\n• Приложениях от незнакомых разработчиков\n\n✅ ALADDIN проверяет каждое приложение перед установкой."),
        
        FAQItem(icon: "💬", question: "Что такое SMS-мошенничество?", answer: "SMS-мошенничество - это обманные сообщения на телефон:\n• \"Вы выиграли! Переведите деньги для получения приза\"\n• \"Ваш банковский счёт заблокирован. Перейдите по ссылке\"\n• \"Ваша посылка задержана. Оплатите доставку\"\n\n❌ НИКОГДА не переводи деньги незнакомцам по SMS!\n\n✅ ALADDIN блокирует такие сообщения и предупреждает об обмане."),
        
        FAQItem(icon: "📍", question: "Что такое геолокационные угрозы?", answer: "Геолокация - это информация о том, где ты находишься. Опасность в том, что:\n• Мошенники могут узнать, где ты живёшь\n• Понять, когда тебя нет дома\n• Следить за тобой\n• Использовать это для кражи\n\nЭто как если бы кто-то знал, где ты находишься каждую минуту!\n\n✅ ALADDIN защищает информацию о твоём местоположении."),
        
        // ==========================================
        // 🏠 СЕМЕЙНЫЕ УГРОЗЫ (2 вопроса)
        // ==========================================
        
        FAQItem(icon: "💔", question: "Что такое домашнее насилие в сети?", answer: "Домашнее насилие в сети - это когда кто-то из семьи контролирует другого через интернет:\n• Следит за всеми сообщениями\n• Блокирует общение с друзьями\n• Угрожает\n• Шантажирует\n\nЭто очень опасно и незаконно!\n\n✅ ALADDIN Premium помогает обнаружить такие ситуации и защитить жертву."),
        
        FAQItem(icon: "😟", question: "Что такое эмоциональные проблемы?", answer: "Эмоциональные проблемы - это когда интернет плохо влияет на настроение:\n• Ребёнок становится грустным после соцсетей\n• Сравнивает себя с другими и расстраивается\n• Видит много негатива\n• Изолируется от реальных друзей\n\n✅ ALADDIN помогает отслеживать эмоциональное состояние и предупреждает родителей, если что-то не так."),
        
        // ==========================================
        // 🔐 ВОЕННАЯ ЗАЩИТА (3 вопроса)
        // ==========================================
        
        FAQItem(icon: "🔐", question: "Что такое военное шифрование AES-256?", answer: "AES-256 - это самый сильный способ защиты информации, который используют:\n• Банки\n• Военные\n• Правительства\n• Спецслужбы\n\nЭто как сейф с миллионом замков - никто не сможет его открыть!\n\n✅ ALADDIN Premium использует AES-256 для максимальной защиты."),
        
        FAQItem(icon: "👻", question: "Что такое анонимность в интернете?", answer: "Анонимность - это когда никто не знает, кто ты:\n• Не видно твой IP-адрес\n• Нельзя отследить, что ты делаешь\n• Нельзя узнать, где ты находишься\n• Никто не может шпионить за тобой\n\nЭто как невидимость - тебя видят, но не знают, кто ты!\n\n✅ ALADDIN Premium делает тебя полностью анонимным в интернете."),
        
        FAQItem(icon: "🏛️", question: "Что такое защита критической инфраструктуры?", answer: "Критическая инфраструктура - это очень важные системы:\n• Больницы\n• Электростанции\n• Водопровод\n• Транспорт\n• Банки\n\nЕсли их взломают - могут пострадать тысячи людей!\n\n✅ ALADDIN Premium защищает такие системы от взлома."),
        
        // ==========================================
        // 💻 ТЕХНИЧЕСКИЕ ВОПРОСЫ (3 вопроса)
        // ==========================================
        
        FAQItem(icon: "💻", question: "Как работает VPN?", answer: "VPN - это как туннель под землёй. Когда ты в интернете:\n• Обычно: Твой телефон → Провайдер → Интернет (все видят, куда ты идёшь)\n• С VPN: Твой телефон → Зашифрованный туннель → Интернет (никто не видит!)\n\nЭто как невидимость - интернет видит, что кто-то сидит онлайн, но не знает, кто именно!\n\n✅ ALADDIN использует VPN для защиты всех твоих данных."),
        
        FAQItem(icon: "👨‍👩‍👧‍👦", question: "Как настроить родительский контроль?", answer: "Очень просто!\n\n1. Открой раздел \"Семья\"\n2. Выбери ребёнка\n3. Настрой:\n   • Сколько времени можно сидеть в телефоне\n   • Какие сайты можно открывать\n   • Какие приложения можно использовать\n   • С кем можно общаться\n\n✅ ALADDIN помогает родителям защитить детей, но не шпионить за ними."),
        
        FAQItem(icon: "💳", question: "Как отменить подписку?", answer: "Легко! 😊\n\n1. Открой \"Настройки\"\n2. Найди \"Управление подпиской\"\n3. Выбери \"Отменить подписку\"\n\nИли напиши нам в поддержку - мы поможем!\n\nМы будем скучать, но понимаем твой выбор! 💙")
    ]
    
    // MARK: - Body
    
    var body: some View {
        ZStack {
            // Фон
            LinearGradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
                .accessibilityElement()
                .accessibilityLabel("Фон экрана поддержки")
            
            VStack(spacing: 0) {
                // Навигационная панель
                HStack {
                    Button(action: {
                        // ✅ ГИБРИДНЫЙ ПОДХОД: dismiss() как основной механизм + синхронизация NavigationManager
                        // dismiss() - использует встроенный механизм SwiftUI, работает надёжно
                        dismiss()
                        
                        // Дополнительно синхронизируем NavigationManager для корректной работы стека
                        DispatchQueue.main.async {
                            if navigationManager.canGoBack {
                                navigationManager.goBack()
                            }
                        }
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                    }
                    .accessibilityLabel("Назад")
                    .accessibilityHint("Нажмите для возврата к предыдущему экрану")
                    
                    Spacer()
                    
                    VStack {
                        Text(localizationManager.localized("support_title"))
                            .font(.headline)
                            .foregroundColor(.white)
                            .accessibilityLabel(localizationManager.localized("support_title"))
                            .accessibilityAddTraits(.isHeader)
                        
                        Text(localizationManager.localized("support_subtitle"))
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .accessibilityLabel(localizationManager.localized("support_subtitle"))
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("Заголовок поддержки")
                    
                    Spacer()
                    
                    Color.clear
                        .frame(width: 40, height: 40)
                }
                .padding()
                .background(Color.black.opacity(0.5))
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Навигационная панель поддержки")
                
                // Основной контент
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 16) {
                        // Поиск
                        searchBar
                        
                        // Способы связи
                        contactMethods
                        
                        // FAQ
                        faqSection
                        
                        // Spacer
                        Spacer()
                            .frame(height: 32)
                    }
                    .padding(.top, 12)
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel("Содержимое поддержки")
            }
        }
        .navigationBarHidden(true)
        .safeAreaInset(edge: .top) {
            Color.clear.frame(height: 12)
        }
        .task {
            print("🚨 SupportScreen загружен!")
        }
        // ✅ Пересоздаём View при изменении языка для обновления всех текстов
        .id("support_lang_\(localizationManager.currentLanguage.rawValue)")
    }
    
    // MARK: - Search Bar
    
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
                .accessibilityLabel("Поиск")
            
            TextField(localizationManager.localized("support_search_placeholder"), text: $searchText)
                .textFieldStyle(PlainTextFieldStyle())
                .accessibilityLabel("Поле поиска по вопросам")
                .accessibilityHint("Введите текст для поиска в часто задаваемых вопросах")
        }
        .padding()
        .background(Color.gray.opacity(0.3))
        .cornerRadius(8)
        .padding(.horizontal, 20)
        .cardShadow()
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Поиск по вопросам")
    }
    
    // MARK: - Contact Methods
    
    private var contactMethods: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(localizationManager.localized("support_contact_us"))
                .font(.title2)
                .foregroundColor(.primary)
                .padding(.horizontal, 20)
                .accessibilityLabel("СВЯЗАТЬСЯ С НАМИ")
                .accessibilityAddTraits(.isHeader)
            
            VStack(spacing: 8) {
                contactButton(icon: "💬", title: localizationManager.localized("support_chat"), subtitle: localizationManager.localized("support_chat_subtitle"), color: .blue)
                contactButton(icon: "📧", title: localizationManager.localized("support_email"), subtitle: "support@aladdin.family", color: .green)
                contactButton(icon: "📱", title: localizationManager.localized("support_phone"), subtitle: "+7 (800) 555-35-35", color: .orange)
            }
            .padding(.horizontal, 20)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Способы связи с поддержкой")
    }
    
    private func contactButton(icon: String, title: String, subtitle: String, color: Color) -> some View {
        Button(action: {
            if title == localizationManager.localized("support_chat") {
                // Открыть чат с AI поддержкой
                if let url = URL(string: "https://t.me/aladdin_support_bot") {
                    UIApplication.shared.open(url)
                }
            } else if title == localizationManager.localized("support_email") {
                // Открыть почтовый клиент
                if let url = URL(string: "mailto:support@aladdin.family") {
                    UIApplication.shared.open(url)
                }
            } else if title == localizationManager.localized("support_phone") {
                // Позвонить
                if let url = URL(string: "tel:+78005553535") {
                    UIApplication.shared.open(url)
                }
            } else {
                print(title)
            }
        }) {
            HStack(spacing: 12) {
                Text(icon)
                    .font(.system(size: 32))
                    .accessibilityLabel("Иконка \(title)")
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.body.bold())
                        .foregroundColor(.primary)
                        .accessibilityLabel("Название: \(title)")
                    
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .accessibilityLabel("Описание: \(subtitle)")
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(title): \(subtitle)")
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(color)
                    .accessibilityLabel("Перейти")
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.3))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(color.opacity(0.3), lineWidth: 1)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
        .cardShadow()
        .appGlassmorphism()
        .accessibilityLabel("\(title): \(subtitle)")
        .accessibilityHint("Нажмите для \(title.lowercased())")
    }
    
    // MARK: - FAQ Section
    
    private var faqSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(localizationManager.localized("support_faq"))
                .font(.title2)
                .foregroundColor(.primary)
                .padding(.horizontal, 20)
                .accessibilityLabel("ЧАСТЫЕ ВОПРОСЫ")
                .accessibilityAddTraits(.isHeader)
            
            VStack(spacing: 8) {
                ForEach($faqItems) { $item in
                    faqCard(item: $item)
                }
            }
            .padding(.horizontal, 20)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Часто задаваемые вопросы")
    }
    
    private func faqCard(item: Binding<FAQItem>) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            // Вопрос
            Button(action: {
                withAnimation(.spring()) {
                    item.wrappedValue.isExpanded.toggle()
                }
            }) {
                HStack(spacing: 12) {
                    Text(item.wrappedValue.icon)
                        .font(.system(size: 24))
                        .accessibilityLabel("Иконка вопроса")
                    
                    Text(item.wrappedValue.question)
                        .font(.body.bold())
                        .foregroundColor(.primary)
                        .accessibilityLabel("Вопрос: \(item.wrappedValue.question)")
                    
                    Spacer()
                    
                    Image(systemName: item.wrappedValue.isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.blue)
                        .accessibilityLabel(item.wrappedValue.isExpanded ? "Свернуть ответ" : "Развернуть ответ")
                }
            }
            .buttonStyle(PlainButtonStyle())
            .accessibilityLabel(item.wrappedValue.isExpanded ? "Свернуть: \(item.wrappedValue.question)" : "Развернуть: \(item.wrappedValue.question)")
            .accessibilityHint("Нажмите для \(item.wrappedValue.isExpanded ? "сворачивания" : "разворачивания") ответа")
            
            // Ответ (раскрывается)
            if item.wrappedValue.isExpanded {
                Text(item.wrappedValue.answer)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding(.leading, 36)
                    .transition(.opacity)
                    .accessibilityLabel("Ответ: \(item.wrappedValue.answer)")
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.3))
        )
        .cardShadow()
        .accessibilityElement(children: .contain)
        .accessibilityLabel("FAQ: \(item.wrappedValue.question)")
    }
}

// MARK: - Preview

struct SupportScreen_Previews: PreviewProvider {
    static var previews: some View {
        SupportScreen()
    }
}



