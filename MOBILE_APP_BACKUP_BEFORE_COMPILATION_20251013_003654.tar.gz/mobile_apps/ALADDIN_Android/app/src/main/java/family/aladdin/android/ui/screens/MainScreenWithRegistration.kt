package family.aladdin.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import family.aladdin.android.ui.components.modals.*
import family.aladdin.android.viewmodels.FamilyRegistrationViewModel
import kotlinx.coroutines.delay

/**
 * 📱 Main Screen with Progressive Registration
 * Обёртка для MainScreen с прогрессивной регистрацией
 * 
 * Показывает модальные окна регистрации поверх MainScreen:
 * - Окно #0: Consent Modal (согласие с Privacy Policy)
 * - Окно #1: Выбор роли (через 0.5 сек после consent)
 * - Окно #2: Выбор возраста (через 1 сек после роли)
 * - Окно #3: Выбор буквы (через 1 сек после возраста)
 * - Окно #4: Семья создана! (через 2 сек после буквы)
 * - Notification: Подсказка (через 5 сек после создания)
 */
@Composable
fun MainScreenWithRegistration(
    registrationVM: FamilyRegistrationViewModel = viewModel()
) {
    var showTip by remember { mutableStateOf(false) }
    
    Box(modifier = Modifier.fillMaxSize()) {
        // Main Screen (основной экран)
        MainScreen()
        
        // МОДАЛКА #0: Consent (Согласие с Privacy Policy)
        if (registrationVM.showConsentModal) {
            ConsentModal(
                onDismiss = { /* Нельзя закрыть */ },
                onAccept = {
                    registrationVM.acceptConsent()
                },
                onReadMore = {
                    // TODO: Открыть PrivacyPolicyScreen
                    // navController.navigate("privacy_policy")
                }
            )
        }
        
        // МОДАЛКА #1: Выбор роли
        if (registrationVM.showRoleModal) {
            RoleSelectionModal(
                onDismiss = { /* Нельзя закрыть на первой регистрации */ },
                onRoleSelected = { role ->
                    registrationVM.onRoleSelected(role)
                }
            )
        }
        
        // МОДАЛКА #2: Выбор возраста
        if (registrationVM.showAgeGroupModal) {
            AgeGroupSelectionModal(
                onDismiss = { /* Нельзя закрыть */ },
                onAgeGroupSelected = { ageGroup ->
                    registrationVM.onAgeGroupSelected(ageGroup)
                }
            )
        }
        
        // МОДАЛКА #3: Выбор буквы
        if (registrationVM.showLetterModal) {
            LetterSelectionModal(
                onDismiss = { /* Нельзя закрыть */ },
                selectedLetter = registrationVM.selectedLetter,
                onLetterSelected = { letter ->
                    registrationVM.onLetterSelected(letter)
                }
            )
        }
        
        // МОДАЛКА #4: Семья создана!
        if (registrationVM.showFamilyCreatedModal) {
            registrationVM.familyID?.let { familyID ->
                registrationVM.recoveryCode?.let { recoveryCode ->
                    FamilyCreatedModal(
                        onDismiss = { /* Нельзя закрыть */ },
                        familyID = familyID,
                        recoveryCode = recoveryCode,
                        onContinue = {
                            registrationVM.showFamilyCreatedModal = false
                            
                            // Показать подсказку через 5 секунд
                            kotlinx.coroutines.GlobalScope.launch {
                                delay(5000)
                                showTip = true
                                
                                // Auto-dismiss через 10 секунд
                                delay(10000)
                                showTip = false
                            }
                        }
                    )
                }
            }
        }
        
        // МОДАЛКА #5: Успешное присоединение/восстановление
        if (registrationVM.showSuccessModal) {
            RegistrationSuccessModal(
                onDismiss = { /* Нельзя закрыть */ },
                mode = RegistrationSuccessModal.Mode.JOINED,
                familyMembers = registrationVM.familyMembers,
                onContinue = {
                    registrationVM.showSuccessModal = false
                }
            )
        }
        
        // TIP NOTIFICATION (Подсказка)
        if (showTip) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 60.dp)
            ) {
                TipNotification(
                    message = "Хотите добавить членов семьи?\n→ Настройки → Семья → \"Добавить члена семьи\"",
                    onDismiss = { showTip = false }
                )
            }
        }
    }
    
    // Автоматический старт регистрации при первом запуске
    LaunchedEffect(Unit) {
        registrationVM.startRegistration()
    }
}

/**
 * Tip Notification Component
 * Подсказка для пользователя
 */
@Composable
fun TipNotification(
    message: String,
    onDismiss: () -> Unit
) {
    androidx.compose.material3.Card(
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .padding(16.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = androidx.compose.ui.graphics.Color(0xFF3B82F6)
        ),
        elevation = androidx.compose.material3.CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.material3.Text(
                text = message,
                color = androidx.compose.ui.graphics.Color.White,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
            
            androidx.compose.material3.IconButton(
                onClick = onDismiss
            ) {
                androidx.compose.material3.Text(
                    text = "✕",
                    color = androidx.compose.ui.graphics.Color.White,
                    fontSize = 18.sp
                )
            }
        }
    }
}

