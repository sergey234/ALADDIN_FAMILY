package family.aladdin.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import family.aladdin.android.ui.components.buttons.PrimaryButton
import family.aladdin.android.ui.components.inputs.ALADDINTextField
import family.aladdin.android.ui.components.navigation.ALADDINTopAppBar
import family.aladdin.android.ui.theme.*

/**
 * 🔄 Forgot Password Screen
 */

@Composable
fun ForgotPasswordScreen(navController: NavController) {
    
    var email by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }
    
    Box(modifier = Modifier.fillMaxSize().backgroundGradient()) {
        Column(modifier = Modifier.fillMaxSize()) {
            ALADDINTopAppBar(
                title = "Восстановление пароля",
                onBackClick = { navController.popBackStack() }
            )
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(ScreenPadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (isSuccess) {
                    Text("✅", style = Typography.headlineLarge.copy(fontSize = 80.sp))
                    Spacer(modifier = Modifier.height(SpacingL))
                    Text("Письмо отправлено!", style = Typography.headlineMedium, color = SuccessGreen)
                    Spacer(modifier = Modifier.height(SpacingM))
                    Text("Проверьте почту $email", style = Typography.bodyMedium, color = TextSecondary)
                    Spacer(modifier = Modifier.height(SpacingXL))
                    PrimaryButton(text = "Вернуться к входу", onClick = { navController.popBackStack() })
                } else {
                    Text("🔑", style = Typography.headlineLarge.copy(fontSize = 80.sp))
                    Spacer(modifier = Modifier.height(SpacingL))
                    Text("Забыли пароль?", style = Typography.headlineMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(SpacingM))
                    Text("Введите email для восстановления", style = Typography.bodyMedium, color = TextSecondary)
                    Spacer(modifier = Modifier.height(SpacingXL))
                    
                    ALADDINTextField(value = email, onValueChange = { email = it }, placeholder = "Email", leadingIcon = "✉️")
                    Spacer(modifier = Modifier.height(SpacingL))
                    
                    PrimaryButton(
                        text = if (isLoading) "Отправка..." else "Отправить инструкции",
                        onClick = { isLoading = true; isSuccess = true },
                        enabled = email.isNotEmpty() && !isLoading
                    )
                }
            }
        }
    }
}

