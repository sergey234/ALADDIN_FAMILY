package family.aladdin.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.navigation.NavController
import family.aladdin.android.ui.components.buttons.PrimaryButton
import family.aladdin.android.ui.components.buttons.SecondaryButton
import family.aladdin.android.ui.components.inputs.ALADDINTextField
import family.aladdin.android.ui.theme.*

/**
 * 🔐 Login Screen
 * Экран входа в приложение
 */

@Composable
fun LoginScreen(navController: NavController) {
    
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .backgroundGradient()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(ScreenPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(SpacingXXL))
            
            // Logo and Title
            Text(
                text = "🛡️",
                style = Typography.headlineLarge.copy(fontSize = 80.sp)
            )
            
            Spacer(modifier = Modifier.height(SpacingL))
            
            Text(
                text = "ALADDIN",
                style = Typography.headlineLarge,
                color = SecondaryGold
            )
            
            Text(
                text = "AI Защита Семьи",
                style = Typography.headlineMedium,
                color = TextPrimary
            )
            
            Spacer(modifier = Modifier.height(SpacingXXL))
            
            // Login Form
            ALADDINTextField(
                value = email,
                onValueChange = { email = it },
                placeholder = "Email",
                leadingIcon = "✉️"
            )
            
            Spacer(modifier = Modifier.height(SpacingM))
            
            ALADDINTextField(
                value = password,
                onValueChange = { password = it },
                placeholder = "Пароль",
                leadingIcon = "🔑",
                isPassword = true
            )
            
            Spacer(modifier = Modifier.height(SpacingS))
            
            // Forgot Password
            Text(
                text = "Забыли пароль?",
                style = Typography.bodySmall,
                color = SecondaryGold,
                modifier = Modifier
                    .align(Alignment.End)
                    .clickable { navController.navigate("forgot_password") }
            )
            
            Spacer(modifier = Modifier.height(SpacingL))
            
            // Login Button
            PrimaryButton(
                text = if (isLoading) "Вход..." else "Войти",
                onClick = {
                    isLoading = true
                    // TODO: Call API
                },
                enabled = email.isNotEmpty() && password.isNotEmpty() && !isLoading
            )
            
            Spacer(modifier = Modifier.height(SpacingL))
            
            // Divider
            Text(
                text = "или",
                style = Typography.bodySmall,
                color = TextSecondary
            )
            
            Spacer(modifier = Modifier.height(SpacingL))
            
            // Social Login
            SecondaryButton(text = "Войти через Apple", onClick = {})
            Spacer(modifier = Modifier.height(SpacingM))
            SecondaryButton(text = "Войти через Google", onClick = {})
            Spacer(modifier = Modifier.height(SpacingM))
            SecondaryButton(text = "Войти через VK", onClick = {})
            
            Spacer(modifier = Modifier.height(SpacingXL))
            
            // Registration Link
            Row {
                Text(
                    text = "Нет аккаунта? ",
                    style = Typography.bodyMedium,
                    color = TextSecondary
                )
                Text(
                    text = "Зарегистрироваться",
                    style = Typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = SecondaryGold,
                    modifier = Modifier.clickable {
                        navController.navigate("registration")
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(SpacingXXL))
        }
    }
}

