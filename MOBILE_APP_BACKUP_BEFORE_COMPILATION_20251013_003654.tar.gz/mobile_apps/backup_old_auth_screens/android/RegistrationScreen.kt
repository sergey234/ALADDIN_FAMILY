package family.aladdin.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import family.aladdin.android.ui.components.buttons.PrimaryButton
import family.aladdin.android.ui.components.inputs.ALADDINTextField
import family.aladdin.android.ui.components.navigation.ALADDINTopAppBar
import family.aladdin.android.ui.theme.*

/**
 * 📝 Registration Screen
 * Экран регистрации
 */

@Composable
fun RegistrationScreen(navController: NavController) {
    
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var agreeToTerms by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    
    val canRegister = name.isNotEmpty() && email.isNotEmpty() && 
                      password.isNotEmpty() && password == confirmPassword && 
                      agreeToTerms && !isLoading
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .backgroundGradient()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            ALADDINTopAppBar(
                title = "Регистрация",
                onBackClick = { navController.popBackStack() }
            )
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(ScreenPadding)
            ) {
                
                ALADDINTextField(value = name, onValueChange = { name = it }, placeholder = "Имя и Фамилия", leadingIcon = "👤")
                Spacer(modifier = Modifier.height(SpacingM))
                
                ALADDINTextField(value = email, onValueChange = { email = it }, placeholder = "Email", leadingIcon = "✉️")
                Spacer(modifier = Modifier.height(SpacingM))
                
                ALADDINTextField(value = password, onValueChange = { password = it }, placeholder = "Пароль", leadingIcon = "🔑", isPassword = true)
                Spacer(modifier = Modifier.height(SpacingM))
                
                ALADDINTextField(value = confirmPassword, onValueChange = { confirmPassword = it }, placeholder = "Подтвердите пароль", leadingIcon = "🔑", isPassword = true)
                Spacer(modifier = Modifier.height(SpacingL))
                
                // Terms Agreement
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = agreeToTerms,
                        onCheckedChange = { agreeToTerms = it }
                    )
                    Column {
                        Text("Я согласен с", style = Typography.bodySmall, color = TextSecondary)
                        Row {
                            Text("Политикой", style = Typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SecondaryGold)
                            Text(" и ", style = Typography.bodySmall, color = TextSecondary)
                            Text("Условиями", style = Typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SecondaryGold)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(SpacingL))
                
                PrimaryButton(
                    text = if (isLoading) "Регистрация..." else "Зарегистрироваться",
                    onClick = { isLoading = true },
                    enabled = canRegister
                )
            }
        }
    }
}

