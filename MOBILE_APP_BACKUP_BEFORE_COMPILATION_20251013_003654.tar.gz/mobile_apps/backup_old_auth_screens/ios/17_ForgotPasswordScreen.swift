import SwiftUI

/**
 * 🔄 Forgot Password Screen
 * Экран восстановления пароля
 */

struct ForgotPasswordScreen: View {
    
    @Environment(\.dismiss) var dismiss
    
    @State private var email: String = ""
    @State private var isLoading: Bool = false
    @State private var isSuccess: Bool = false
    @State private var errorMessage: String? = nil
    
    var body: some View {
        ZStack {
            LinearGradient.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: Spacing.xl) {
                // Navigation Bar
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.bodyBold)
                            .foregroundColor(.textPrimary)
                            .frame(width: Size.navButtonSize, height: Size.navButtonSize)
                            .background(Color.surfaceDark.opacity(0.6))
                            .cornerRadius(CornerRadius.medium)
                    }
                    Spacer()
                }
                .padding(.horizontal, Spacing.screenPadding)
                
                Spacer()
                
                if isSuccess {
                    // Success State
                    VStack(spacing: Spacing.xl) {
                        Text("✅")
                            .font(.system(size: Size.iconXLarge * 2))
                        
                        Text("Письмо отправлено!")
                            .font(.h1)
                            .foregroundColor(.successGreen)
                        
                        Text("Проверьте почту \(email)")
                            .font(.body)
                            .foregroundColor(.textSecondary)
                            .multilineTextAlignment(.center)
                        
                        Text("Мы отправили инструкции по восстановлению пароля")
                            .font(.caption)
                            .foregroundColor(.textTertiary)
                            .multilineTextAlignment(.center)
                        
                        PrimaryButton(title: "Вернуться к входу") {
                            dismiss()
                        }
                        .padding(.top, Spacing.xl)
                    }
                    .padding(.horizontal, Spacing.screenPadding)
                } else {
                    // Form State
                    VStack(spacing: Spacing.xl) {
                        VStack(spacing: Spacing.m) {
                            Text("🔑")
                                .font(.system(size: Size.iconXLarge * 1.5))
                            
                            Text("Забыли пароль?")
                                .font(.h1)
                                .foregroundColor(.textPrimary)
                            
                            Text("Введите email и мы отправим инструкции для восстановления")
                                .font(.body)
                                .foregroundColor(.textSecondary)
                                .multilineTextAlignment(.center)
                        }
                        
                        VStack(spacing: Spacing.l) {
                            ALADDINTextField(
                                placeholder: "Email",
                                text: $email,
                                icon: "✉️",
                                errorMessage: errorMessage
                            )
                            
                            PrimaryButton(
                                title: isLoading ? "Отправка..." : "Отправить инструкции",
                                action: sendResetEmail,
                                isDisabled: isLoading || email.isEmpty
                            )
                            
                            Button(action: { dismiss() }) {
                                Text("Вернуться к входу")
                                    .font(.body)
                                    .foregroundColor(.textSecondary)
                            }
                        }
                    }
                    .padding(.horizontal, Spacing.screenPadding)
                }
                
                Spacer()
            }
        }
    }
    
    // MARK: - Actions
    
    private func sendResetEmail() {
        isLoading = true
        errorMessage = nil
        HapticFeedback.mediumImpact()
        
        // TODO: Call API reset password
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            isLoading = false
            isSuccess = true
            print("Reset email sent")
        }
    }
}

// MARK: - Preview

struct ForgotPasswordScreen_Previews: PreviewProvider {
    static var previews: some View {
        ForgotPasswordScreen()
    }
}

