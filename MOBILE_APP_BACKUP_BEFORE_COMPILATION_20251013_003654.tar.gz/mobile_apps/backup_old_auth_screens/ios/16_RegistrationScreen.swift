import SwiftUI

/**
 * 📝 Registration Screen
 * Экран регистрации нового пользователя
 */

struct RegistrationScreen: View {
    
    @Environment(\.dismiss) var dismiss
    
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var phone: String = ""
    @State private var agreeToTerms: Bool = false
    @State private var isLoading: Bool = false
    @State private var errorMessage: String? = nil
    @State private var showPrivacyPolicy: Bool = false
    @State private var showTerms: Bool = false
    
    var body: some View {
        ZStack {
            LinearGradient.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Navigation Bar
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.bodyBold)
                            .foregroundColor(.textPrimary)
                            .frame(width: Size.navButtonSize, height: Size.navButtonSize)
                            .background(Color.surfaceDark.opacity(0.6))
                            .cornerRadius(CornerRadius.medium)
                    }
                    
                    Spacer()
                    
                    Text("Регистрация")
                        .font(.h2)
                        .foregroundColor(.secondaryGold)
                    
                    Spacer()
                    
                    Color.clear.frame(width: Size.navButtonSize, height: Size.navButtonSize)
                }
                .padding(.horizontal, Spacing.screenPadding)
                .padding(.top, Spacing.m)
                
                ScrollView {
                    VStack(spacing: Spacing.l) {
                        Spacer().frame(height: 20)
                        
                        // Registration Form
                        VStack(spacing: Spacing.m) {
                            ALADDINTextField(
                                placeholder: "Имя и Фамилия",
                                text: $name,
                                icon: "👤"
                            )
                            
                            ALADDINTextField(
                                placeholder: "Email",
                                text: $email,
                                icon: "✉️"
                            )
                            
                            ALADDINTextField(
                                placeholder: "Телефон (опционально)",
                                text: $phone,
                                icon: "📱"
                            )
                            
                            ALADDINTextField(
                                placeholder: "Пароль",
                                text: $password,
                                isSecure: true,
                                icon: "🔑"
                            )
                            
                            ALADDINTextField(
                                placeholder: "Подтвердите пароль",
                                text: $confirmPassword,
                                isSecure: true,
                                icon: "🔑",
                                errorMessage: password != confirmPassword && !confirmPassword.isEmpty ? "Пароли не совпадают" : nil
                            )
                        }
                        
                        // Terms Agreement
                        Button(action: {
                            agreeToTerms.toggle()
                            HapticFeedback.selection()
                        }) {
                            HStack(spacing: Spacing.m) {
                                Image(systemName: agreeToTerms ? "checkmark.square.fill" : "square")
                                    .foregroundColor(agreeToTerms ? .successGreen : .textSecondary)
                                    .font(.title2)
                                
                                VStack(alignment: .leading, spacing: Spacing.xxs) {
                                    Text("Я согласен с")
                                        .font(.caption)
                                        .foregroundColor(.textSecondary)
                                    
                                    HStack(spacing: 4) {
                                        Button("Политикой конфиденциальности") {
                                            showPrivacyPolicy = true
                                        }
                                        .font(.captionBold)
                                        .foregroundColor(.secondaryGold)
                                        
                                        Text("и")
                                            .font(.caption)
                                            .foregroundColor(.textSecondary)
                                        
                                        Button("Условиями использования") {
                                            showTerms = true
                                        }
                                        .font(.captionBold)
                                        .foregroundColor(.secondaryGold)
                                    }
                                }
                                
                                Spacer()
                            }
                        }
                        .padding(Spacing.m)
                        .background(Color.surfaceDark.opacity(0.3))
                        .cornerRadius(CornerRadius.medium)
                        
                        // Register Button
                        PrimaryButton(
                            title: isLoading ? "Регистрация..." : "Зарегистрироваться",
                            action: register,
                            isDisabled: !canRegister
                        )
                        
                        // Login Link
                        Button(action: { dismiss() }) {
                            HStack(spacing: Spacing.xs) {
                                Text("Уже есть аккаунт?")
                                    .font(.body)
                                    .foregroundColor(.textSecondary)
                                Text("Войти")
                                    .font(.bodyBold)
                                    .foregroundColor(.secondaryGold)
                            }
                        }
                    }
                    .padding(.horizontal, Spacing.screenPadding)
                }
            }
        }
        .sheet(isPresented: $showPrivacyPolicy) {
            PrivacyPolicyScreen()
        }
        .sheet(isPresented: $showTerms) {
            TermsOfServiceScreen()
        }
    }
    
    // MARK: - Computed Properties
    
    private var canRegister: Bool {
        !name.isEmpty &&
        !email.isEmpty &&
        !password.isEmpty &&
        password == confirmPassword &&
        agreeToTerms &&
        !isLoading
    }
    
    // MARK: - Actions
    
    private func register() {
        isLoading = true
        errorMessage = nil
        HapticFeedback.mediumImpact()
        
        // TODO: Call API register
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            isLoading = false
            dismiss()
            print("Registration successful")
        }
    }
}

// MARK: - Preview

struct RegistrationScreen_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationScreen()
    }
}

