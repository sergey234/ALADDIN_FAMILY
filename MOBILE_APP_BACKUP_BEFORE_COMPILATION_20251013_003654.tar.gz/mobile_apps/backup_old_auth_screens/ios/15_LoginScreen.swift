import SwiftUI

/**
 * 🔐 Login Screen
 * Экран входа в приложение
 */

struct LoginScreen: View {
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String? = nil
    @State private var showRegistration: Bool = false
    @State private var showForgotPassword: Bool = false
    
    var body: some View {
        ZStack {
            LinearGradient.backgroundGradient
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: Spacing.xl) {
                    Spacer().frame(height: 60)
                    
                    // Logo and Title
                    VStack(spacing: Spacing.m) {
                        Text("🛡️")
                            .font(.system(size: Size.iconXLarge * 2))
                        
                        Text("ALADDIN")
                            .font(.largeTitle)
                            .foregroundColor(.secondaryGold)
                        
                        Text("AI Защита Семьи")
                            .font(.h2)
                            .foregroundColor(.textPrimary)
                    }
                    
                    Spacer().frame(height: 40)
                    
                    // Login Form
                    VStack(spacing: Spacing.l) {
                        ALADDINTextField(
                            placeholder: "Email",
                            text: $email,
                            icon: "✉️",
                            errorMessage: errorMessage
                        )
                        
                        ALADDINTextField(
                            placeholder: "Пароль",
                            text: $password,
                            isSecure: true,
                            icon: "🔑"
                        )
                        
                        // Forgot Password
                        Button(action: {
                            showForgotPassword = true
                            HapticFeedback.lightImpact()
                        }) {
                            Text("Забыли пароль?")
                                .font(.caption)
                                .foregroundColor(.secondaryGold)
                        }
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        
                        // Login Button
                        PrimaryButton(
                            title: isLoading ? "Вход..." : "Войти",
                            action: login,
                            isDisabled: isLoading || email.isEmpty || password.isEmpty
                        )
                        
                        // Divider
                        HStack {
                            Rectangle()
                                .fill(Color.textTertiary)
                                .frame(height: 1)
                            Text("или")
                                .font(.caption)
                                .foregroundColor(.textSecondary)
                            Rectangle()
                                .fill(Color.textTertiary)
                                .frame(height: 1)
                        }
                        .padding(.vertical, Spacing.m)
                        
                        // Social Login Buttons
                        SecondaryButton(title: "Войти через Apple", icon: nil) { print("Apple Login") }
                        SecondaryButton(title: "Войти через Google", icon: nil) { print("Google Login") }
                        SecondaryButton(title: "Войти через VK", icon: nil) { print("VK Login") }
                        
                        // Registration Link
                        Button(action: {
                            showRegistration = true
                            HapticFeedback.lightImpact()
                        }) {
                            HStack(spacing: Spacing.xs) {
                                Text("Нет аккаунта?")
                                    .font(.body)
                                    .foregroundColor(.textSecondary)
                                Text("Зарегистрироваться")
                                    .font(.bodyBold)
                                    .foregroundColor(.secondaryGold)
                            }
                        }
                        .padding(.top, Spacing.l)
                    }
                    .padding(.horizontal, Spacing.screenPadding)
                    
                    Spacer()
                }
            }
        }
        .sheet(isPresented: $showRegistration) {
            RegistrationScreen()
        }
        .sheet(isPresented: $showForgotPassword) {
            ForgotPasswordScreen()
        }
    }
    
    // MARK: - Actions
    
    private func login() {
        isLoading = true
        errorMessage = nil
        HapticFeedback.mediumImpact()
        
        // TODO: Call API login
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            isLoading = false
            // Navigate to Main Screen on success
            print("Login successful")
        }
    }
}

// MARK: - Preview

struct LoginScreen_Previews: PreviewProvider {
    static var previews: some View {
        LoginScreen()
    }
}

