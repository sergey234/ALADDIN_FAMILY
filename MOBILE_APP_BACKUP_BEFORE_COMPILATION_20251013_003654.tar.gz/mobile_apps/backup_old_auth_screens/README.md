# 📦 BACKUP: Старые экраны аутентификации

## ⚠️ ПОЧЕМУ ЗДЕСЬ:

Эти экраны **противоречат концепции анонимности** ALADDIN:

### Старая система (НЕ используется):
- ❌ Регистрация через Email + Password
- ❌ Логин через Email + Password  
- ❌ Восстановление через Email
- ❌ Сбор персональных данных

### Новая система (ИСПОЛЬЗУЕТСЯ):
- ✅ Анонимная регистрация (БЕЗ email/телефона)
- ✅ QR-коды для добавления членов семьи
- ✅ Роль + Возраст + Буква (вместо имени)
- ✅ Соответствие 152-ФЗ

---

## 📁 СОДЕРЖИМОЕ:

### iOS (3 файла):
- `15_LoginScreen.swift` - старый экран логина
- `16_RegistrationScreen.swift` - старая регистрация
- `17_ForgotPasswordScreen.swift` - восстановление пароля

### Android (3 файла):
- `LoginScreen.kt` - старый экран логина
- `RegistrationScreen.kt` - старая регистрация
- `ForgotPasswordScreen.kt` - восстановление пароля

---

## 🔄 ВОССТАНОВЛЕНИЕ:

Если понадобится вернуть эти экраны:

```bash
# iOS
mv mobile_apps/backup_old_auth_screens/ios/*.swift mobile_apps/ALADDIN_iOS/Screens/

# Android
mv mobile_apps/backup_old_auth_screens/android/*.kt mobile_apps/ALADDIN_Android/app/src/main/java/family/aladdin/android/ui/screens/
```

---

## 🗑️ УДАЛЕНИЕ:

Если уверены что не понадобятся:

```bash
rm -rf mobile_apps/backup_old_auth_screens/
```

---

**Дата перемещения:** 2025-10-11  
**Причина:** Переход на анонимную регистрацию с QR-кодами  
**Статус:** Архив (не используется в production)

